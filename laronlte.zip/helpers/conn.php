<?php 
#Establish database connection
require 'config.php';
$con=mysqli_connect($dbServer,$dbUsername,$dbPassword,$dbDatabase);
if (mysqli_connect_errno()) {
	# code...
	echo "Error:".mysqli_connect_error();
}
?>