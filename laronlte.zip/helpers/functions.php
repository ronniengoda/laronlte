<?php 
#######################################################
/*ADD YOUR CUSTOM FUNCTIONS HERE*/