##A List of most important functions you may need to use in your application dashbaord interface.

#LaRonCustomSidenavMenu("Link","Icon","Name","Color","Count");

#LaRonCustomTableCard("Color","Icon","Name","Count","Link");

#LaRonDataCard("color","name","icon","value");

#LaRonDataCard2("color","name","icon","value");

#LaRonBox("color","title","body");

#LaRonAlert("color","icon","title","content");

#LaRonCallout("color","title","content");

#LaRonModal("color","modalID","btntext","title","body");

#LaRonValues("query");

#LaRonValue("query");

#LaRonSQL("query");