<?php 
/*LaRon Dahboard Framework is designed for the lazy appgini developers to easily integrate different admin templates into their applications with much less pain and repetitive coding.

****Author Ronald-Ngoda-ronniengoda@gmail.com|www.ronaldngoda.info****

##Include this file at the top of your main dashboard interface.

MOST IMPORTANT FUNCTIONS TO USE
-getLoggedMemberID()-This gives you the currently logged in member
-getMemberInfo()-This gives you an array with details of the current member like username,group,groupID,custom fields
-LaRonUserMenu()-To display contents of the user menu
-LaRonSideNavMenu()-To display contents of the side nav menu
-LaRonTableCards()-To display the table cards on the dashboard.
-LaRonCustomSidenavMenu()-To show custom side nav menu items
-LaRonCustomTableCards()-To show custom table cards
-LaRonGetActualValue()- is used to get an actual value from a parent table field using a primary key(which should be id) you provide.
*/

#You can create your own custom functions here and call them wherever you have included this file.

#Include important things first
@include("{$currDir}/hooks/links-home.php");
if(!defined('PREPEND_PATH')) define('PREPEND_PATH', '');
if(!defined('datalist_db_encoding')) define('datalist_db_encoding', 'UTF-8');

#Redirect guest users to login page
$currentuser=getLoggedMemberID();
if ($currentuser=="guest") {
	redirect("index.php?signIn=1");
}

#Variables that will be handy
$info=getMemberInfo();
$username=$info['username'];
$group=$info['group'];
$groupID=$info['groupID'];
$custom1=$info['custom']['0'];
$custom2=$info['custom']['1'];
$custom3=$info['custom']['2'];
$custom4=$info['custom']['3'];

	//Custom Project Variables.
	$ProjectInitials="PINS";//initials of your project name
	$ProjectName="Project Name";//your full project name
	$CatchLine="Catchy Intro Line";//a catchy intro line for your project

	#LaRonUserMenu function that will be displaying the userprofile,logout,adminarea buttons/links and any other custom item you want
	function LaRonUserMenu(){
		global $group;
		$group=$group;
		$userprofileLink=PREPEND_PATH."membership_profile.php";
		$logoutLink=PREPEND_PATH."index.php?signOut=1";
		if ($group=="Admins") {
		# code...
			$adminareaLink=PREPEND_PATH."admin/pageHome.php";
		#display admin area button/link below here
			echo'<!-- Menu Body -->
			<li class="user-body">
			<div class="row">
			<div class="col-xs-12 text-center">
			<a href="'.$adminareaLink.'" class="btn btn-success btn-block"><b>Admin Area</b></a>
			</div>
			<!-- /.row -->
			</li>';
		}
	//echo '<a href="'.$userprofileLink.'">Demo Link</a>';
	#display userprofile,logout link and anyother item here
		echo' <!-- Menu Footer-->
		<li class="user-footer">
		<div class="pull-left">
		<a href="'.$userprofileLink.'" class="btn btn-default"><b>Profile</b></a>
		</div>
		<div class="pull-right">
		<a href="'.$logoutLink.'" class="btn btn-default"><b>Sign out</b></a>
		</div>
		</li>';
	}

#LaRonSideNavMenu function to display the links on the side navbar
	function LaRonSideNavMenu(){
		global $groupID;
		$groupID=$groupID;
		@include 'conn.php';
		$customQuery=mysqli_query($con,"SELECT DISTINCT tableName FROM membership_grouppermissions");
		foreach ($customQuery as $key => $result) {
		# code...
			$tableList=$result['tableName'];
		$tableName=preg_replace("/[^a-zA-Z]/", " ", $tableList);//remove speacial characters like "_"
		$tableNameFormatted=ucwords($tableName);//Make every first letter of name upper case

		//Define menu icons in the included file below
		@include 'tableCardsConfig.php';

		$getTblPermissions=mysqli_query($con,"SELECT allowInsert,allowView FROM membership_grouppermissions WHERE tableName='$tableList' AND groupID='$groupID'");
		foreach ($getTblPermissions as $key => $data) {
			# code...
			$AI= $data['allowInsert'];
			$AV= $data['allowView'];
			if ($AI>0 ||$AV>0) {
				if($sidenav_visible=="true") {
				# code...
				#display links here and throw in the following variables
				/*$tableList."_view.php"-to detail view;
				$tableNameFormatted-to show menu title;
				$card_icon-to show menu icon
				$menu_icon-only if icons differ*/
				echo '<li>
				<a href="'.$tableList.'_view.php">
				<i class="'.$card_icon.'"></i> <span><b>'.$tableNameFormatted.'</b></span>
				</a>
				</li>';
			}
		}
	}
}
}

#LaRonTableCards Function to display table cards
function LaRonTableCards(){
	global $groupID,$username;
	$groupID=$groupID;
	$username=$username;
	@include 'conn.php';

	$customQuery=mysqli_query($con,"SELECT DISTINCT tableName FROM membership_grouppermissions");
	foreach ($customQuery as $key => $result) {
	# code...
		$tableList=$result['tableName'];
	$tableName=preg_replace("/[^a-zA-Z]/", " ", $tableList);//remove speacial characters like "_"
	$tableNameFormatted=ucwords($tableName);//Make every first letter of name upper case
	$getTblPermissions=mysqli_query($con,"SELECT allowInsert,allowView FROM membership_grouppermissions WHERE tableName='$tableList' AND groupID='$groupID'");
	foreach ($getTblPermissions as $key => $data) {
		# code...
		$AI= $data['allowInsert'];
		$AV= $data['allowView'];
		if ($AI>0 ||$AV>0) {
			# code...count records
			$countOwner=mysqli_query($con,"SELECT * FROM membership_userrecords WHERE memberID='$username' AND tableName='$tableList'");
			$recordcountOwner=mysqli_num_rows($countOwner);
			$countGroup=mysqli_query($con,"SELECT * FROM membership_userrecords WHERE groupID='$groupID' AND tableName='$tableList'");
			$recordcountGroup=mysqli_num_rows($countGroup);
			$countAll=mysqli_query($con,"SELECT * FROM $tableList");
			$recordcountAll=mysqli_num_rows($countAll);

			#####################################
			#check possible scenarios.
			if ($AI==0 && $AV==1) {
				# code...
				$recordCount=$recordcountOwner;
			}
			elseif ($AI==0 && $AV==2) {
				# code...
				$recordCount=$recordcountGroup;
			}
			elseif ($AI==0 && $AV==3) {
				# code...
				$recordCount=$recordcountAll;
			}
			elseif ($AI==1 && $AV==0) {
				# code...
				$recordCount=$recordcountOwner;
			}
			elseif ($AI==1 && $AV==1) {
				# code...
				$recordCount=$recordcountOwner;
			}
			elseif ($AI==1 && $AV==2) {
				# code...
				$recordCount=$recordcountGroup;
			}
			elseif ($AI==1 && $AV==3) {
				# code...
				$recordCount=$recordcountAll;
			}
			#################################

			//Define card icons and colors in the included file below.
			@include 'tableCardsConfig.php';
			######################################
			if ($tablecard_visible=="true") {
				# code...
			//display your cards here and throw in the following variables
			/*$card_color-to show card color
			,$recordCount-to show record count
			,$tableNameFormatted-to show table name formatted
			,$card_icon-to show card icon
			,$tableList."_view.php"-to give link to detail view
			*/
			echo' <div class="col-md-3 col-sm-6 col-xs-12">
			<div class="info-box bg-'.$card_color.'">
			<span class="info-box-icon"><i class="'.$card_icon.'"></i></span>

			<div class="info-box-content">
			<span class="info-box-text"><b>'.$tableNameFormatted.'</b></span>
			<span class="info-box-number">'.$recordCount.'</span>

			<div class="progress">
			<div class="progress-bar" style="width: 100%"></div>
			</div>
			<span class="progress-description">
			<strong><a href="'.$tableList."_view.php".'" style="text-decoration: none;color: white">View Details</a> <span class="fa  fa-arrow-circle-o-right"></span></strong>
			</span>
			</div>
			<!-- /.info-box-content -->
			</div>
			<!-- /.info-box -->
			</div>';
		}
	}
}

}
}

#LaRonCustomSidenavMenu to display custom menus on the sidenav based on your own custom queries and preference.
function LaRonCustomSidenavMenu(){
	@include 'conn.php';
	 ##############################
	 //Display Custom Menus Here
	 ##############################
}

#LaRonCustomTableCards to display custom table cards based on your own custom queries and preference.
function LaRonCustomTableCards(){
	@include 'conn.php';
	 ##############################
	 //Display custom cards here
	 ##############################
}

#LaRonGetActualValue is used to get an actual value from a parent table field using a primary key(which should be id) you provide.
function LaRonGetActualValue($parentTable,$field,$pkValue){
	@include 'conn.php';
	$result=mysqli_query($con,"SELECT `$field` FROM `$parentTable` WHERE `id`='$pkValue'");
	while ($data=mysqli_fetch_array($result)) {
		# code...
		return $data[$field];
	}
}

#######################################################
/*ADD YOUR CUSTOM FUNCTIONS BELOW HERE*/

?>