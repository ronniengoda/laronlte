<?php 
/*LaRon Dahboard Framework is designed for the lazy appgini developers to easily integrate different admin templates into their applications with much less pain and repetitive coding.

****Author Ronald-Ngoda-ronniengoda@gmail.com|www.ronaldngoda.info****

##Include this file at the top of your main dashboard interface.
*/

#Include important things first.
@include("{$currDir}/hooks/links-home.php");
if(!defined('PREPEND_PATH')) define('PREPEND_PATH', '');
if(!defined('datalist_db_encoding')) define('datalist_db_encoding', 'UTF-8');
include 'conn.php';

#Redirect guest users to login page
$currentuser=getLoggedMemberID();
if ($currentuser=="guest") {
	redirect("index.php?signIn=1");
}

#Variables that will be handy
$info=getMemberInfo();
$username=$info['username'];
$email=$info['email'];
$group=$info['group'];
$groupID=$info['groupID'];
$custom1=$info['custom']['0'];
$custom2=$info['custom']['1'];
$custom3=$info['custom']['2'];
$custom4=$info['custom']['3'];

	//Custom Project Variables.
	$ProjectInitials="PINS";//initials of your project name
	$ProjectName="Project Name";//your full project name
	$CatchLine="Catchy Intro Line";//a catchy intro line for your project
	$skinColor="blue-light";//Options: blue,black,purple,green,red,yellow,blue-light,black-light,purple-light,green-light,red-light,yellow-light

	#LaRonUserMenu function that will be displaying the userprofile,logout,adminarea buttons/links and any other custom item you want
	function LaRonUserMenu(){
		global $group;
		$userprofileLink=PREPEND_PATH."membership_profile.php";
		$logoutLink=PREPEND_PATH."index.php?signOut=1";
		if ($group=="Admins") {
		# code...
			$adminareaLink=PREPEND_PATH."admin/pageHome.php";
		#display admin area button/link below here
			echo'<!-- Menu Body -->
			<li class="user-body">
			<div class="row">
			<div class="col-xs-12 text-center">
			<a class="btn btn-app" href="'.$adminareaLink.'">
			<i class="fa fa-cogs"></i> <b>Admin Area</b>
			</a>
			</div>
			<!-- /.row -->
			</li>';
		}
	//echo '<a href="'.$userprofileLink.'">Demo Link</a>';
	#display userprofile,logout link and anyother item here
		echo' <!-- Menu Footer-->
		<li class="user-footer">
		<div class="pull-left">
		<a href="'.$userprofileLink.'" class="btn btn-default"><b>Profile</b></a>
		</div>
		<div class="pull-right">
		<a href="'.$logoutLink.'" class="btn btn-default"><b>Sign out</b></a>
		</div>
		</li>';
	}

#LaRonSideNavMenu function to display the links on the side navbar
	function LaRonSideNavMenu(){
		global $groupID,$con;
		$customQuery=mysqli_query($con,"SELECT DISTINCT tableName FROM membership_grouppermissions ORDER BY permissionID");
		foreach ($customQuery as $key => $result) {
		# code...
			$tableList=$result['tableName'];
		$tableName=preg_replace("/[^a-zA-Z]/", " ", $tableList);//remove speacial characters like "_"
		$tableNameFormatted=ucwords($tableName);//Make every first letter of name upper case

		$TVlink=$tableList."_view.php";
		//Define menu icons and label colors in the included file below
		@include 'tableCardsConfig.php';

		$getTblPermissions=mysqli_query($con,"SELECT allowInsert,allowView FROM membership_grouppermissions WHERE tableName='$tableList' AND groupID='$groupID'");
		foreach ($getTblPermissions as $key => $data) {
			# code...
			$AI= $data['allowInsert'];
			$AV= $data['allowView'];
			if ($AI>0 ||$AV>0) {
				if($sidenav_visible=="true") {
					$recordCount=LaRonrecordCount($tableList,$AI,$AV);
				# code...
				#display links here and throw in the following variables
				/*$tableList."_view.php"-to detail view;
				$tableNameFormatted-to show menu title;
				$card_icon-to show menu icon
				$menu_icon-only if icons differ
				$label_color-the color for your labels*/
				if ($label_visible=="true") {
					# code...
					$showlabel='<span class="label label-'.$label_color.' pull-right">'.$recordCount.'</span>';
				}
				else{
					$showlabel="";
				}
				echo '<li>
				<a href="'.$TVlink.'">
				<i class="'.$card_icon.'"></i> <span><b>'.$tableNameFormatted.'</b></span>
				<span class="pull-right-container">
				'.$showlabel.'
				</span>
				</a>
				</li>';
			}
		}
	}
}
}

#LaRonTableCards Function to display table cards
function LaRonTableCards(){
	global $groupID,$username,$con;

	$customQuery=mysqli_query($con,"SELECT DISTINCT tableName FROM membership_grouppermissions ORDER BY permissionID");
	foreach ($customQuery as $key => $result) {
	# code...
		$tableList=$result['tableName'];
	$tableName=preg_replace("/[^a-zA-Z]/", " ", $tableList);//remove speacial characters like "_"
	$tableNameFormatted=ucwords($tableName);//Make every first letter of name upper case
	$getTblPermissions=mysqli_query($con,"SELECT allowInsert,allowView FROM membership_grouppermissions WHERE tableName='$tableList' AND groupID='$groupID'");
	foreach ($getTblPermissions as $key => $data) {
		# code...
		$AI= $data['allowInsert'];
		$AV= $data['allowView'];
		$TVlink=$tableList."_view.php";
		if ($AI>0 ||$AV>0) {
			
			$recordCount=LaRonrecordCount($tableList,$AI,$AV);
			if ($AI==1) {
				# code...Allow add new from home page
				$addNew='<strong class="pull-right" data-toggle="tooltip" data-placement="top" title="Add New"><a href="'.$tableList.'_view.php?addNew_x=1" style="color:white"><span class="fa  fa-plus"></span></a></strong>';
			}
			else{
				$addNew="";
			}
			#################################

			//Define card icons and colors in the included file below.
			@include 'tableCardsConfig.php';
			######################################
			if ($tablecard_visible=="true") {
				# code...
			//display your cards here and throw in the following variables
			/*$card_color-to show card color
			,$recordCount-to show record count
			,$tableNameFormatted-to show table name formatted
			,$card_icon-to show card icon
			,$tableList."_view.php"-to give link to detail view
			*/
			echo' <div class="col-md-3 col-sm-6 col-xs-12">
			<div class="info-box bg-'.$card_color.'">
			<span class="info-box-icon"><i class="'.$card_icon.'"></i></span>

			<div class="info-box-content">
			<span class="info-box-text"><b>'.$tableNameFormatted.'</b></span>
			<span class="info-box-number">'.$recordCount.'</span>

			<div class="progress">
			<div class="progress-bar" style="width: 100%"></div>
			</div>
			<span class="progress-description">
			<strong data-toggle="tooltip" data-placement="top" title="View Details"><a href="'.$TVlink."".'" style="text-decoration: none;color: white">View Details</a> <span class="fa  fa-arrow-circle-o-right"></span></strong>
			'.$addNew.'
			</span>
			</div>
			<!-- /.info-box-content -->
			</div>
			<!-- /.info-box -->
			</div>';
		}
	}
}

}
}

#LaRonCustomSidenavMenu to display custom menus on the sidenav based on your own custom queries and preference.
function LaRonCustomSidenavMenu($Link,$Icon,$Name,$Color,$Count=null){
	 ##############################
	 //Display Custom Menus Here
	echo '<li>
	<a href="'.$Link.'">
	<i class="fa fa-'.$Icon.'"></i> <span><b>'.$Name.'</b></span>
	<span class="pull-right-container">
	<span class="label label-'.$Color.' pull-right">'.$Count.'</span>
	</span>
	</a>
	</li>';
	 ##############################
}

#LaRonCustomTableCards to display custom table cards based on your own custom queries and preference.
function LaRonCustomTableCard($Color,$Icon,$Name,$Count,$Link){
	 ##############################
	 //Display custom cards here
	$content=' <div class="col-md-3 col-sm-6 col-xs-12">
	<div class="info-box bg-'.$Color.'">
	<span class="info-box-icon"><i class="fa fa-'.$Icon.'"></i></span>

	<div class="info-box-content">
	<span class="info-box-text"><b>'.$Name.'</b></span>
	<span class="info-box-number">'.$Count.'</span>

	<div class="progress">
	<div class="progress-bar" style="width: 100%"></div>
	</div>
	<span class="progress-description">
	<strong data-toggle="tooltip" data-placement="top" title="View Details"><a href="'.$Link."".'" style="text-decoration: none;color: white">View Details</a> <span class="fa  fa-arrow-circle-o-right"></span></strong>
	</span>
	</div>
	<!-- /.info-box-content -->
	</div>
	<!-- /.info-box -->
	</div>';
	return $content;
	 ##############################
}

#LaRonCustomTableCards to display custom table cards based on your own custom queries and preference.
function LaRonCustomTableCard2($Color,$Icon,$Name,$Count,$Link){
	 ##############################
	 //Display custom cards here
	$content='<div class="col-lg-3 col-xs-6">
	<!-- small box -->
	<div class="small-box bg-'.$Color.'">
	<div class="inner">
	<h3>'.$Count.'</h3>

	<p>'.$Name.'</p>
	</div>
	<div class="icon">
	<i class="fa fa-'.$Icon.'"></i>
	</div>
	<a href="'.$Link.'" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
	</div>
	</div>
	<!-- ./col -->';
	return $content;
	 ##############################
}

#LaRonDataCard is used to display a card with data either a counter or value you wish
function LaRonDataCard($color,$name,$icon,$value){
	$content='<div class="col-lg-3 col-xs-6">
	<!-- small box -->
	<div class="small-box bg-'.$color.'">
	<div class="inner">
	<h3>'.$value.'</h3>
	<p><strong>'.$name.'</strong></p>
	</div>
	<div class="icon">
	<i class="fa fa-'.$icon.'"></i>
	</div>
	</div>
	</div>';
	return $content;
}

#LaRonDataCard2 is used to display a card with data either a counter or value you wish
function LaRonDataCard2($color,$name,$icon,$value){
	$content='<div class="col-md-3 col-sm-6 col-xs-12">
	<div class="info-box">
	<span class="info-box-icon bg-'.$color.'"><i class="fa fa-'.$icon.'"></i></span>
	<div class="info-box-content">
	<span class="info-box-text">'.$name.'</span>
	<span class="info-box-number">'.$value.'</span>
	</div>
	<!-- /.info-box-content -->
	</div>
	<!-- /.info-box -->
	</div>
	<!-- /.col -->';
	return $content;
}

#LaRonBox is used to display a box with custom body data.This box can be removed or collapsed.
function LaRonBox($color,$title,$body){
	echo'<div class="box box-'.$color.' box-solid">
	<div class="box-header with-border">
	<h3 class="box-title">'.$title.'</h3>

	<div class="box-tools pull-right">
	<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
	</button>
	<button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
	</div>
	<!-- /.box-tools -->
	</div>
	<!-- /.box-header -->
	<div class="box-body">
	'.$body.'
	</div>
	<!-- /.box-body -->
	</div>
	<!-- /.box -->';
}

#LaRonBox is used to display a box with custom body
function LaRonBoxLite($color,$title,$body){
	echo'<div class="box box-'.$color.'">
	<div class="box-header">
	<h3 class="box-title">'.$title.'</h3>
	</div>
	<div class="box-body">'.$body.'</div>
	</div>';
}

#LaRonAlert is used to display an alert with an icon,title and conent.
function LaRonAlert($color,$icon,$title,$content){
	$alertcontent='<div class="alert alert-'.$color.' alert-dismissible">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
	<h4><i class="icon fa fa-'.$icon.'"></i> '.$title.'</h4>
	'.$content.'
	</div>';
	return $alertcontent;
}

#LaRonCallout is used to display a callout with title and conent.
function LaRonCallout($color,$title,$content){
	$calloutcontent='<div class="callout callout-'.$color.'">
	<h4>'.$title.'</h4>
	<p>'.$content.'</p>
	</div>';
	return $calloutcontent;
}

#LaRonModal is used to display a button that launches a modal with a title and content
function LaRonModal($color,$modalID,$btntext,$title,$body){
	$modalbtn='<button type="button" class="btn btn-'.$color.'" data-toggle="modal" data-target="#'.$modalID.'">
	'.$btntext.'
	</button>';
	echo'<div class="modal modal-'.$color.' fade" id="'.$modalID.'">
	<div class="modal-dialog">
	<div class="modal-content">
	<div class="modal-header">
	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
	<span aria-hidden="true">&times;</span></button>
	<h4 class="modal-title">'.$title.'</h4>
	</div>
	<div class="modal-body">
	'.$body.'
	</div>
	<div class="modal-footer">
	<button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
	</div>
	</div>
	<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
	</div>
	<!-- /.modal -->';
	return $modalbtn;
}

#LaRonValues is used to get all values from a query you provide.
function LaRonValues($query){
	global $con;
	$result=mysqli_query($con,$query);
	$values=mysqli_fetch_array($result);
	return $values;
}

#LaRonValue is used to return a single value from your query
function LaRonValue($query){
	global $con;
	$result=mysqli_query($con,$query);
	$value=mysqli_fetch_array($result);
	return $value[0];
}

#LaRonSQL is used to perform any sql query operation to insert,update and delete.
function LaRonSQL($query){
	global $con;
	if($result=mysqli_query($con,$query)) {
		# code...
		return TRUE;
	}
}

#LaRonrecordCount is used to count table records according to table permssions.
function LaRonrecordCount($tableList,$AI,$AV){
	global $con,$groupID,$username;
	# code...count records
	$countOwner=mysqli_query($con,"SELECT * FROM membership_userrecords WHERE memberID='$username' AND tableName='$tableList'");
	$recordcountOwner=mysqli_num_rows($countOwner);
	$countGroup=mysqli_query($con,"SELECT * FROM membership_userrecords WHERE groupID='$groupID' AND tableName='$tableList'");
	$recordcountGroup=mysqli_num_rows($countGroup);
	$countAll=mysqli_query($con,"SELECT * FROM $tableList");
	$recordcountAll=mysqli_num_rows($countAll);
			#####################################
			#check possible scenarios.
	if ($AI==0 && $AV==1) {
				# code...
		$recordCount=$recordcountOwner;
	}
	elseif ($AI==0 && $AV==2) {
				# code...
		$recordCount=$recordcountGroup;
	}
	elseif ($AI==0 && $AV==3) {
				# code...
		$recordCount=$recordcountAll;
	}
	elseif ($AI==1 && $AV==0) {
				# code...
		$recordCount=$recordcountOwner;
	}
	elseif ($AI==1 && $AV==1) {
				# code...
		$recordCount=$recordcountOwner;
	}
	elseif ($AI==1 && $AV==2) {
				# code...
		$recordCount=$recordcountGroup;
	}
	elseif ($AI==1 && $AV==3) {
				# code...
		$recordCount=$recordcountAll;
	}
	return $recordCount;
}

//LaRonJsonResponse is used to respond to API requests in general.
function LaRonJsonResponse($code = 200,$response = null){
		//USAGE
		/*echo json_response(200, array(
	  	'Receiver' =>$Receiver,
	  	'Message'=>$Message,
	  	'username'=>$username,
	  	'apiKey'=>$apiKey
	  ));*/
		//echo json_response(200,'Data received successfully');
		//echo json_response(500,'Server Error! Please Try Again!');

    	// clear the old headers
	  header_remove();
    	// set the actual code
	  http_response_code($code);
    	// set the header to make sure cache is forced
	  header("Cache-Control: no-transform,public,max-age=300,s-maxage=900");
    	// treat this as json
	  header('Content-Type: application/json');
	  $status = array(
	  	200 => '200 OK',
	  	400 => '400 Bad Request',
	  	422 => 'Unprocessable Entity',
	  	500 => '500 Internal Server Error'
	  );
    	// ok, validation error, or failure
  		//header('Status: '.$status[$code]);
	  header('Status: '.$code);
    	// return the encoded json
	  return json_encode(array(
        'status' => $code < 300,// success or not?
        'response' => $response
    ));
	}

//LaRonAPIRequest is used to send an API request.It sends(POST) given json data to a url you provide.
	function LaRonAPIRequest($url,$data){
		//Initiate cURL.
		$ch = curl_init($url);

		//Tell cURL that we want to send a POST request.
		curl_setopt($ch, CURLOPT_POST, 1);

		//Attach our encoded JSON string to the POST fields.
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

		//Set the content type to application/json.
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

		//Dont return result to screen,store in a variable.
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);

		//Execute the request.
		$result = curl_exec($ch);
		return $result;
	}

	function LaRonAppButtonBadge($btnName,$icon,$link,$counter,$color){
		$button='<a class="btn btn-app" href="'.$link.'">
		<span class="badge bg-'.$color.'">'.$counter.'</span>
		<i class="fa fa-'.$icon.'"></i> '.$btnName.'
		</a>';
		return $button;
	}

	function LaRonAppButton($btnName,$link,$icon){
		$button=' <a class="btn btn-app" href="'.$link.'">
		<i class="fa fa-'.$icon.'"></i> '.$btnName.'
		</a>';
		return $button;
	}

	function LaRonSocialButton($text,$link,$type,$size){
		$block='<a class="btn btn-block btn-social btn-'.$type.'" href="'.$link.'">
		<i class="fa fa-'.$type.'"></i> '.$text.'
		</a>';
		$small='<a class="btn btn-social-icon btn-'.$type.'" href="'.$link.'"><i class="fa fa-'.$type.'"></i></a>';

		if ($size=="block") {
        	# code...
			return $block;
		}
		if ($size=="small") {
        	# code...
			return $small;
		}
	}

	function LaRonSplitButton($btnType,$btnText,$dropdownMenu){
		$menus=explode(',',$dropdownMenu);
		$allitems='';
		foreach ($menus as $item) {
                  		# code...
			$menuItem=$item;
			$split=explode('*', $menuItem);
			$link=$split[0];
			$text=$split[1];
			$allitems.='<li><a href="'.$link.'" target="blank">'.$text.'</a></li>';
		}

		$splitbutton='<div class="btn-group">
		<button type="button" class="btn btn-'.$btnType.'">'.$btnText.'</button>
		<button type="button" class="btn btn-'.$btnType.' dropdown-toggle" data-toggle="dropdown">
		<span class="caret"></span>
		<span class="sr-only">Toggle Dropdown</span>
		</button>
		<ul class="dropdown-menu" role="menu">
		'.$allitems.'
		</ul>
		</div>';
		return $splitbutton;
	}

	function LaRonPieChart($title,$is3D,$chartHeight,$chartWidth,$data){
		$piechart='<script type="text/javascript">
		google.charts.load("current", {"packages":["corechart"]});
		google.charts.setOnLoadCallback(drawChart);

		function drawChart() {

			var data = google.visualization.arrayToDataTable([
			'.$data.'
			]);

			var options = {
				title: "'.$title.'",
				is3D: '.$is3D.',
			};

			var chart = new google.visualization.PieChart(document.getElementById("piechart"));

			chart.draw(data, options);
		}
		</script>';
		$piechart.='<div id="piechart" style="height: '.$chartHeight.'px;width:'.$chartWidth.'px"></div>';
		return $piechart;
	}

	function LaRonDonutChart($title,$chartHeight,$chartWidth,$data){
		$donutchart='<script type="text/javascript">
		google.charts.load("current", {packages:["corechart"]});
		google.charts.setOnLoadCallback(drawChart);
		function drawChart() {
			var data = google.visualization.arrayToDataTable([
			'.$data.'
			]);

			var options = {
				title: "'.$title.'",
				pieHole: 0.4,
			};

			var chart = new google.visualization.PieChart(document.getElementById("donutchart"));
			chart.draw(data, options);
		}
		</script>';
		$donutchart.='<div id="donutchart" style="height: '.$chartHeight.'px;width:'.$chartWidth.'px"></div>';
		return $donutchart;
	}

	function LaRonBarChart($title,$subtitle,$data){
		$barchart="<script type='text/javascript'>
		google.charts.load('current', {'packages':['bar']});
		google.charts.setOnLoadCallback(drawChart);

		function drawChart() {
			var data = google.visualization.arrayToDataTable([
			".$data."
			]);

			var options = {
				chart: {
					title: '".$title."',
					subtitle: '".$subtitle."',
					},
					bars: 'vertical',
					vAxis: {format: 'decimal'},
					height: 400,
					colors: ['#1b9e77', '#d95f02', '#7570b3']
				};

				var chart = new google.charts.Bar(document.getElementById('barchart'));

				chart.draw(data, google.charts.Bar.convertOptions(options));

				var btns = document.getElementById('btn-group');

				btns.onclick = function (e) {

					if (e.target.tagName === 'BUTTON') {
						options.vAxis.format = e.target.id === 'none' ? '' : e.target.id;
						chart.draw(data, google.charts.Bar.convertOptions(options));
					}
				}
			}
			</script>";
			$barchart.="<div id='barchart'></div>";

			return $barchart;
		}