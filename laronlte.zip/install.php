<?php 
define("PREPEND_PATH", "");
$hooks_dir = dirname(__FILE__);
include("defaultLang.php");
include("language.php");
include("lib.php");
include_once("header.php");

require_once 'helpers/conn.php';

$myfile = fopen("helpers/tableCardsConfig.php", "w") or die("An error occured-Unable to open file!");
$indexfile=fopen("index.php", "w") or die("An error occured-Unable to open file!");

$phpopen = "<?php\n";
fwrite($myfile,$phpopen);
$topcomments = '/*In this script define your table card colors and icons in each case.You will define the "$card_icon" and "$card_color" use this format for each table:

case "tablename":
$card_icon="fa fa-table";
$menu_icon="fa fa-money";
$card_color="blue";
break;

If table card_icons differ with sidemenu icons uncomment the variable $menu_icon in each case and place the menu icon there.This should be used in the function SideNavMenu();

You can also hide or show tableCards based on username,group or groupID.An example is given in the comments for each case.Feel free to modify to suit your needs.
*/'."\n";
fwrite($myfile, $topcomments);
$topvariables='$info=getMemberInfo();
$username=$info["username"];
$group=$info["group"];
$groupID=$info["groupID"];';
fwrite($myfile, $topvariables);

$swithcopen="\n".'switch ($tableList) {
		//For icons reffer to template icons
		//Card colors reffer to template availabe colors.'."\n";
	fwrite($myfile, $swithcopen);
	//Write query to get all tableNames for switch cases
	$caseStatement='';
	$customQuery=mysqli_query($con,"SELECT DISTINCT tableName FROM membership_grouppermissions");
	foreach ($customQuery as $key => $result) {
		$colorCode=mt_rand(1,7);
		switch ($colorCode) {
			case '1':
		# code...
			$color="red";
			$label_color="danger";
			break;
			case '2':
		# code...
			$color="green";
			$label_color="success";
			break;
			case '3':
		# code...
			$color="blue";
			$label_color="primary";
			break;
			case '4':
		# code...
			$color="yellow";
			$label_color="warning";
			break;
			case '5':
		# code...
			$color="orange";
			$label_color="info";
			break;
			case '6':
		# code...
			$color="purple";
			$label_color="success";
			break;
			case '7':
		# code...
			$color="aqua";
			$label_color="danger";
			break;
			default:
		# code...
			break;
		}
		# code...
		$tableList=$result['tableName'];
		$caseStatement.="\t".'case "'.$tableList.'":
		# code...
		$card_icon="fa fa-shopping-cart";
		$card_color="'.$color.'";
		$label_color="'.$label_color.'";
		//$menu_icon="icon";
		/*if ($group=="Admins"||$group=="customers") {
			# code...
			$tablecard_visible="false";
			$sidenav_visible="false";
			$label_visible="true";
		}
		else{$tablecard_visible="true";$sidenav_visible="true";$label_visible="true";}
		*/
		$tablecard_visible="true";
		$sidenav_visible="true";
		$label_visible="true";
		break;'."\n";
	}
	fwrite($myfile, $caseStatement);
	$defaultStatement="\t".'default:
	# code...
	$card_icon="fa fa-shopping-cart";
	$card_color="red";
	$tablecard_visible="true";
	$sidenav_visible="true";
	break;
}'."\n";
fwrite($myfile, $defaultStatement);
$phpclose="?>\n";
fwrite($myfile, $phpclose);
fclose($myfile);

$index='<?php
	$currDir = dirname(__FILE__);
	define("HOMEPAGE", true);
	include("{$currDir}/defaultLang.php");
	include("{$currDir}/language.php");
	include("{$currDir}/lib.php");

	$x = new DataList;
	$x->TableTitle = $Translation["homepage"];

	// according to provided GET parameters, either log out, show login form (possibly with a failed login message), or show homepage
	if(isset($_GET["signOut"])) {
		logOutUser();
		redirect("index.php?signIn=1");
	} elseif(isset($_GET["loginFailed"]) || isset($_GET["signIn"])) {
		if(isset($_GET["loginFailed"])) @header("HTTP/1.0 403 Forbidden");
		include("{$currDir}/login.php");
	} else {
		include("{$currDir}/userdash.php");
	}';
fwrite($indexfile, $index);
fclose($indexfile);

echo "<div class='alert alert-success text-center'><b>LaRon Dashboard Framework Successfully Installed.<br>Redirecting To Dashboard.....</b><div>";
echo '<META HTTP-EQUIV="Refresh" CONTENT="4;url=index.php">';
exit;
?>